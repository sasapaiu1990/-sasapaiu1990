$(document).ready(function(){
        $("#start").click(function(){
        $('div').slideDown(2000);
        $("#start").slideUp(1800)
   



   setInterval(function(){ 
    $(document).ready(function(){
        $("div").animate({left:300, borderRadius:40},1500)
                 .animate({top:300},1500)
                 .animate({left:10},1500)
                 .animate({top:10, borderRadius:10},1500)
    
        });           
},1000); 
       
         $("div:first").click(function(){
            $(this) .css({width:120, height:120, opacity:0.5,})
         }).mouseover(function(){
             $(this) .css({width:80, height:80, opacity:1})
         })
             
        
            
         $("#third").mouseenter(function(){
             $(this).css({'backgroundColor':'#98bf21'})
             }).mouseout(function(){
              $(this).css({'backgroundColor':'blue'})   
             });
 

   });
});     
