// JavaScript Document
var app = angular.module("myapp",[]);
app.controller("mycontr",function($scope){
    
  $scope.toggleActive = function(s){
        s.active = !s.active;
    };
    $scope.total=function(){
       var total=0; 
        
        angular.forEach($scope.items,function(s){
            if(s.active){
                total += s.price ;
                
            }
        });
        return total;
    }
    $scope.tva=function(){
        var tva = 0;
        angular.forEach($scope.items, function(s){
            if(s.active){
              tva += s.price *0.2;
                
            }
        });
        return tva;
    }
    
    $scope.items=[
        {
           name: 'West',
           price:9.90,
           active:true,
        }, {
           name: 'Parliament',
           price:7.20,
           active: false,
        },{
            name: 'Kent',
           price: 7.00,
           active:false,
        },{
            name: 'Marlboro',
           price: 6.9,
           active:false,
        },{
            name: 'Luky Strike',
           price: 6.7,
           active:false,
        }
    ]
});


















