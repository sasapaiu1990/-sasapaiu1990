
<article <?php post_class(); ?> id="post-<?php the_ID(); ?>">
 
    <header >
        <div class="entry_header">
            
        <?php
        if ( is_singular() ) :
            the_title( '<h2 class="entry-title">', '</h1>' );
        else :
            the_title( '<h3 class="entry-title"><a href="' . esc_url( get_permalink() ) . '" rel="bookmark">', '</a></h2>' );
        endif;
 
        if ( 'post' === get_post_type() ) :
            ?>
            <div class="entry-meta">
                <span class="entry-meta-date"><em><?php the_date(); ?></em></span>
                <span class="entry-meta-author"><em> <?php the_author(); ?></em></span>
            </div><!-- .entry-meta -->
        <?php endif; ?>
            </div>
    </header><!-- .entry-header -->
    <div class="posts-content">
 <div class="post_poin"></div>
     
         
    
 
    <?php the_content(); ?>
 </div>
</article>
        