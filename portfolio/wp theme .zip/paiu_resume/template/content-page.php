<article <?php post_class(); ?> id="post-<?php the_ID(); ?>">
 
    <div class="page_content">
    <header class="entry-header">
        <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
    </header><!-- .entry-header -->
        
 
        
<?php the_content(); ?>
    
    </div>
</article>

    <div class="display_widgets">
        <?php  
            if(dynamic_sidebar('new_widget_area')):endif;
        ?>
    </div>