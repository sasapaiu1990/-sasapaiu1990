<?php
class User {

  // Methods
  public function __construct($id, $first_name, $last_name, $age) {
    $this->number = $id;
    $this->name = $first_name;
    $this->family = $last_name;
    $this->age = $age;
	if($this-> age > 18){
	$age[$this->age] = $age;
	echo "welcome <br>";
	} else {
	echo "You have no access <br>";
	}
  }
  public function __destruct() {
    echo "Nr: . {$this->number} <br>Name: {$this->name}. <br> Surname: {$this->family}<br> Age : {$this->age}"; 
  }
}

$q = new User ("1", "Temistocle", "Apolo", "15");
   
?>