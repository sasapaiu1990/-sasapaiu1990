
<html>
<head>
<meta charset="utf-8">
<title>Agenda telefonica</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>


 <div id="wrap">
    <div id="search">
	 <img src="imagini/images.jpg" alt=""/>
	 <br>
	   <a href="remove.php"> <img src="imagini/minus.jpg" title="Remove contact" height="60px"> </a>
	   <a href="index.php"> <img src="imagini/phonebook2.jpg" height="60px" title="Search"> </a>
	   
       
	   <form action="#" method="POST" >
	   
	   <label>First name: <br>
	       <input type="text" name="family" ></label> <br>
		    <label>Last name: <br>
	       <input type="text" name="name" ></label> <br>
		   <label>Tel: <br>
	       <input type="text" name="number" ></label> <br><hr>
		   <input type="submit" name="insert" value="insert"> 
		   
	 </form>
      </div>
	  
	  
     <div id="mesage">
	 <?php
	    if(isset($_POST['insert'])){
			
		  if(isset ($_POST['family']) && isset ($_POST['name']) && isset ($_POST['number'])) {
			  
							 if(!empty($_POST['family']) && !empty($_POST['name']) && !empty( $_POST['number'])){
								 
								 $family = trim($_POST['family']);
								 $name = trim($_POST['name']);
								 $number = trim($_POST['number']);
								 
								 
								 require('inc/conectare.php');
								 
								   $family = mysqli_real_escape_string($conn,$family); 
								   $name = mysqli_real_escape_string($conn,$name); 
								   $number = mysqli_real_escape_string($conn,$number); 
								   
								   $query = "INSERT INTO contacts (family, name, number) VALUES ('{$family}','{$name}','{$number}')";
								  
								  
								  if (mysqli_query($conn, $query) === TRUE){
						
									   	    echo "Client adaugat cu succes";
									   
								   } else {
									    			   
									   echo "ERORR!";
								   }
									
							 } else{ 
				 
				 echo "All fields must be filled in .";
				 
			 }
			  
		  } 
		   
		  
	
		}
	 
	 ?>
	 </div>
	 
</div>


</body>
</html>
