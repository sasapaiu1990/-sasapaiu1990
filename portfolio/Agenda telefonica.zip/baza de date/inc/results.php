<?php
 
require("conectare.php");

if(isset ($_GET['criteria'])){
		 
	     
		 if(!empty ($_GET['criteria'])){
		 
			 $criteriu = trim($_GET['criteria']);
			 $criteriu = mysqli_real_escape_string($conn,$criteriu);
		
			 $query = "SELECT * FROM contacts WHERE family LIKE '%{$criteriu}%' OR name LIKE '%{$criteriu}%' ";
			
			 $result = mysqli_query($conn , $query); 
			 
					if(mysqli_num_rows($result)>0){
			       while($row = mysqli_fetch_assoc($result)){
					 
						?>
						
						<div id="results">
					    <img src="imagini/images.jpg" height="100" align ="right">	
						<p><b>Name: </b><?php echo $row['family'] ." " . $row['name']; ?></p>
						<p><b>Tel: </b> <?php echo $row['number']; ?></p>
						
						</div>
						
							
				        <?php
			        }
			         echo "Number of results: " . mysqli_num_rows($result);
			   
			    } else{
			     
				     echo "Nici un rezultat";
		       }
		    
		   
	 }else{
		   echo "Nu ati introdus nimic ";
	 }
}	 
?>
