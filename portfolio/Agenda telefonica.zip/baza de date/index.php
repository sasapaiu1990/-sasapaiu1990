
<html>
<head>
<meta charset="utf-8">
<title>Agenda telefonica</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>


 <div id="wrap">
    <div id="search">
	 <img src="imagini/phonebook2.jpg" alt="" align="center"/>
	 <div class="search">
	   <a href="remove.php"> <img src="imagini/minus.jpg" height="60px" title="Remove contact" > </a>
	   <a href="insert.php"> <img src="imagini/user_add.jpg" title="Add contact"> </a>
	   </div>
       
	   <form action="#" method="GET" >
	       
          <input type="text" placeholder="phoneboock" name="criteria">
          <input type="submit" value="search">
     <br>
	 </form>
      </div>
     <?php
	 
	 include("inc/results.php");
	 
	 
	 ?>
	 
	 

</div>


</body>
</html>
