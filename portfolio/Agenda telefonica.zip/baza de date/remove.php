
<html>
<head>
<meta charset="utf-8">
<title>Agenda telefonica</title>
<link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>


 <div id="wrap">
    <div id="search">
	 <img src="imagini/delete1.jpg" alt=""/>
	 <br>
	   <a href="insert.php"> <img src="imagini/user_add.jpg" title="Add contact"> </a>
	   <a href="index.php"> <img src="imagini/phonebook2.jpg" height="60px" title="Search"> </a>
	   
  
      </div>
	  
	  <?php
	  
	  require('inc/conectare.php');
	   $query ="SELECT * FROM contacts";
	   $results = mysqli_query($conn,$query);
	   
			if(mysqli_num_rows($results)>0){
				while($row = mysqli_fetch_assoc($results)){
				?>
				<div id="delete" >
				
				<a href="inc/removeContacts.php?id=<?php echo $row['id'] ?>" title="delete" 
				onclick="return confirm('Are you sure?');" >
				<img src="imagini/minus.jpg" alt="delete" align ="right">
				</a>
				
				<span style="font-size:20px;line-height:0.6em;opacity:0.2;">delete</span>
				
				<p><b>Name: </b><?php echo $row['family'] ." " . $row['name']; ?></p>
				<p><b>Tel: </b> <?php echo $row['number']; ?></p>
				
				</div>



				<?php
					
					
				}
			}else{
				echo "No contact";
			}
	  
	  
	  
	  ?>
 
     
	 
</div>


</body>
</html>
